package dc.human.whosthebest.vo;

public class GameAwayMemberListVO {
    private String uName;       //U_NAME
    private String uID;         //U_ID

    public GameAwayMemberListVO() {
    }

    public String getuName() {
        return uName;
    }

    public void setuName(String uName) {
        this.uName = uName;
    }

    public String getuID() {
        return uID;
    }

    public void setuID(String uID) {
        this.uID = uID;
    }
}
