package dc.human.whosthebest.vo;

public class AdminVO {
	
	private String adId;
	   private String adPw;
	   private String adName;
	   private String createdId;
	   private String createdDate;
	   private String updatedId;
	   private String updatedDate;
	
	   
	public AdminVO() {
		
	}


	public String getA_id() {
		return adId;
	}


	public void setA_id(String a_id) {
		this.adId = a_id;
	}


	public String getAdPw() {
		return adPw;
	}


	public void setAdPw(String adPw) {
		this.adPw = adPw;
	}


	public String getAdName() {
		return adName;
	}


	public void setAdName(String adName) {
		this.adName = adName;
	}


	public String getCreatedId() {
		return createdId;
	}


	public void setCreatedId(String createdId) {
		this.createdId = createdId;
	}


	public String getCreatedDate() {
		return createdDate;
	}


	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}


	public String getUpdatedId() {
		return updatedId;
	}


	public void setUpdatedId(String updatedId) {
		this.updatedId = updatedId;
	}


	public String getUpdatedDate() {
		return updatedDate;
	}


	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}
	   
	   

	
}
